DEAD RAILS AI SIMULATOR v0.3

Chạy thử ngay:
1. Giải nén ZIP.
2. Mở index.html bằng Chrome, Edge hoặc Firefox.
3. Chọn Normal / Vampire / Necromancer.
4. Nhấn Chơi lượt mới. Bot tự vận hành trong bản đồ mô phỏng.
5. Dùng Tạm dừng, Một bước và Tốc độ để kiểm tra từng quyết định.

Đưa lên GitHub Pages miễn phí:
1. Đăng nhập https://github.com/
2. Tạo repository mới, ví dụ dead-rails-ai-sim. Chọn Public.
3. Upload index.html và README.md vào thư mục gốc của repository.
4. Vào Settings -> Pages.
5. Trong Build and deployment, chọn Deploy from a branch.
6. Chọn Branch: main và Folder: / (root), sau đó Save.
7. Đợi GitHub tạo trang. Mở URL có dạng https://TEN-TAI-KHOAN.github.io/dead-rails-ai-sim/

Không cần Python, API key, máy chủ riêng hoặc thanh toán.
Ứng dụng chạy JavaScript ngay trong trình duyệt. GitHub Pages chỉ lưu và phân phối file tĩnh.

GIỚI HẠN:
- Đây là mô phỏng độc lập, không kết nối Roblox.
- AI hiện tại là bộ điều khiển luật (rule-based), chưa phải mô hình học sâu. Vampire hồi máu vào ban đêm; Necromancer có đòn hỗ trợ triệu hồi giả lập.
- Các chỉ số và sự kiện được giả lập để kiểm thử logic.
- Không có nhận diện màn hình game thật, không đọc bộ nhớ game, không gửi input tới Roblox.
